import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.sql.*;

public class BookRoomServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        Integer userId = (Integer) session.getAttribute("userId");
        String roomType = request.getParameter("roomType");
        String date = request.getParameter("date");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_db", "root", "@Arsh04");

            PreparedStatement ps = con.prepareStatement("INSERT INTO bookings(user_id, room_type, booking_date) VALUES (?, ?, ?)");
            ps.setInt(1, userId);
            ps.setString(2, roomType);
            ps.setString(3, date);
            ps.executeUpdate();

            
            con.close();
            response.sendRedirect("dashboard.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("dashboard.jsp?error=1");
        }
    }
}
