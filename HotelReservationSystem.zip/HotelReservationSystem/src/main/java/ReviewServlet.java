import java.io.IOException;
import java.sql.*;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ReviewServlet")
public class ReviewServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        String name = request.getParameter("name");
        int rating = Integer.parseInt(request.getParameter("rating"));
        String message = request.getParameter("message");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_db", "root", "@Arsh04");

            String sql = "INSERT INTO reviews (name, rating, message) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, name);
            ps.setInt(2, rating);
            ps.setString(3, message);

            ps.executeUpdate();
            conn.close();

            response.sendRedirect("thankyou.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error submitting review.");
        }
    }
}
