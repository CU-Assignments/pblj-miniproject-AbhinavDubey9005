import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;

public class LogoutServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Invalidate session
        HttpSession session = request.getSession(false); // false = don’t create if not exists
        if (session != null) {
            session.invalidate();
        }
        // Redirect to login page
        response.sendRedirect("login.jsp");
    }
}
